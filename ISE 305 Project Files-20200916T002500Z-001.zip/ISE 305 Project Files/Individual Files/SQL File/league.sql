DROP DATABASE 305_project;
CREATE DATABASE 305_project;
USE 305_project;

CREATE TABLE players(
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    ingame_name VARCHAR(50),
    level INT,
    soloMMR INT,
    ladderRank DOUBLE
);
-- I would like to tie a SINGLE playerChampion to a SINGLE playerGame record to signify what champion a player used that game
-- Maybe this would be a one to one relationship?
CREATE TABLE playerGameStatistics(
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    kills INT,
    deaths INT,
    assists INT,
    gold INT,
    creep_score INT,
    kill_participation DOUBLE

);

-- Possibly create new attribute in leagueGames table named "gameId" that will hold the
-- id for the game instance. In example there may be 5-10 entries that share the same gameId value
-- representing the 5-10 game records of a single league game and their different players and player game statistics

-- Using the game id approach, think about finding the best player for an particular group of game ids as well as their
-- corresponding statistics 

CREATE TABLE leagueGames(
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    game_instance INT,
    game_mode VARCHAR(50),
    game_date DATE,
    game_length TIME,
    playerGameStatistic_id INT,
    player_id INT,
    FOREIGN KEY(playerGameStatistic_id) REFERENCES playerGameStatistics(id) ON DELETE CASCADE,
    FOREIGN KEY(player_id) REFERENCES players(id)  ON DELETE CASCADE
);

CREATE TABLE playerChampion (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    championName VARCHAR(100),
    gamesWon INT,
    gamesLOST INT,
    KDA DOUBLE,
    creepScore DOUBLE,
    averageDamageTaken DOUBLE,
    averageDamageDealt DOUBLE
);

CREATE TABLE leagueChampion (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    championRole VARCHAR(50),
    pickRate DOUBLE,
    winRate DOUBLE,
    banRate DOUBLE,
    championTier INT,
    counteredBy VARCHAR(100),
    counters VARCHAR(100),
    playerChampion_id INT,
    player_id INT,
    FOREIGN KEY(playerChampion_id) REFERENCES playerChampion(id) ON DELETE CASCADE,
    FOREIGN KEY(player_id) REFERENCES players(id) ON DELETE CASCADE
);

CREATE TABLE playerRank(
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    rankType VARCHAR(100),
    rankTier VARCHAR(100),
    rankDivision INT,
    gamesWon INT,
    gamesLost INT,
    LP INT,
    lastSeasonRank_id INT DEFAULT NULL,
    FOREIGN KEY(lastSeasonRank_id) REFERENCES playerRank(id) ON DELETE CASCADE
);

CREATE TABLE leagueRank(
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    rankDistribution DOUBLE,
    tierDistribution DOUBLE,
    tierSurrenderRate DOUBLE,
    tierAFKRate DOUBLE,
    playerRank_id INT,
    player_id INT,
    FOREIGN KEY(playerRank_id) REFERENCES playerRank(id) ON DELETE CASCADE,
    FOREIGN KEY(player_id) REFERENCES players(id) ON DELETE CASCADE
);



INSERT INTO players(ingame_name,level,soloMMR,ladderRank) VALUES
("penpa96",58,1750,.1320),
("Farlaun",110,1600,.2530),
("Clout",100,1770,.1250),
("Full Aggresive",68,1890,.0892),
("zhang96",96,1500,.2822),
("tryoki", 120, 1421, .3419);

INSERT INTO playerGameStatistics(kills, deaths, assists, gold, creep_score, kill_participation) VALUES
(10,2,7,10215,200,.56),
(3,5,2,6321,30,.33),
(0,13,6,7630,174,.42),
(7,4,6,8259,256,.63),
(7,7,7,5983,128,.51),
(1,2,3,4000,65,.21),
(2,5,9,9235,152,.65),
(1,21,6,6219,40,.26),
(9,3,13,12310,236,.72),
(3,2,25,8799,35,.85),
(13,6,10,1459,223,.80),
(5,0,10,10219,209,.69);


INSERT INTO leagueGames(game_instance,game_mode,game_date,game_length,playerGameStatistic_id,player_id) VALUES
(1,"Ranked Solo","2018-10-27","25:11:03",1,1),
(2,"ARAM","2018-10-25","18:52:25",2,1),
(3,"Ranked Solo","2018-10-11","32:42:52",4,3),
(4,"Ranked Flex","2018-09-30","29:21:33",3,5),
(4,"Ranked Flex","2018-09-30","29:21:33",5,2),
(4,"Ranked Flex","2018-09-30","29:21:33",7,4),
(5,"Normal", "2018-09-30", "52:39:26",9,1),
(5,"Normal", "2018-09-30", "52:39:26",12,2),
(5,"Normal", "2018-09-30", "52:39:26",11,4),
(5,"Normal", "2018-09-30", "52:39:26",10,5),
(5,"Normal", "2018-09-30", "52:39:26",8,6);

INSERT INTO playerChampion(championName, gamesWon, gamesLost, KDA, creepScore, averageDamageTaken, averageDamageDealt) VALUES
("Urgot",10,2,2.213,20.2,10312.219,21315.315),
("Kai'Sa",22,7,3.519,23.3,8119.112,25631.731),
("Veigar",15,16,2.002,10.520,9119.912,16219.835),
("Leona",7,4,2.892,9.173,18399.742,12144.912),
("Fizz",12,8,1.931,22.910,15832.921,18742.781);

INSERT INTO leagueChampion(championRole, pickRate, winRate, banRate, championTier, counteredBy, counters, playerChampion_id, player_id) VALUES
("Top",.1495,.5152,.2077,1,"Sion","Ryze",1,1),
("Bottom",.4294,.4957,.1741,2,"Swain","Ezrea",2,4),
("Middle",.0288,.5003,.0049,3,"Rumble","Akali",3,6),
("Support",.1058,.5184,.048,1,"Zilean","Malphite",4,1),
("Middle",.0463,.5194,.0436,2,"Kassadin","Syndra",5,2);

INSERT INTO playerRank(rankType, rankTier, rankDivision, gamesWon, gamesLost, LP, lastSeasonRank_id) VALUES
("Ranked Solo","Platinum",5,32,21,0,NULL),
("Ranked Solo","Gold",4,33,35,100,NULL),
("Ranked Solo","Platinum",5,185,160,0,NULL),
("Ranked Solo","Diamond",5,129,100,100,NULL),
("Ranked Solo","Gold",5,56,59,96,NULL),
("Ranked Solo","Silver",1,21,23,0,NULL);


INSERT INTO leagueRank(rankDistribution, tierDistribution, tierSurrenderRate,tierAFKRate, playerRank_id, player_id) VALUES
(.0448,.0921,.1444,.052,1,1),
(.0594,.3147,.135,.065,2,2),
(.0448,.0921,.1444,.052,3,3),
(.0167,.0237,.175,.044,4,4),
(.1494,.3147,.135,.065,5,5),
(.0503,.4525,.125,.088,6,6);

SELECT
    ingame_name,
    level,
    game_instance,
    game_mode,
    game_length,
    championName,
    championRole,
    kills,
    deaths,
    creep_score
FROM players
INNER JOIN leagueGames
    ON players.id = leagueGames.player_id
INNER JOIN playerGameStatistics
    ON playerGameStatistics.id = leagueGames.playerGameStatistic_id
INNER JOIN leagueChampion
    ON players.id = leagueChampion.player_id
INNER JOIN playerChampion
    ON playerChampion.id = leagueChampion.playerChampion_id
ORDER BY game_instance;

SELECT
    ingame_name,
    level,
    game_instance,
    game_mode,
    game_length,
    kills,
    deaths,
    creep_score
FROM players
INNER JOIN leagueGames
    ON players.id = leagueGames.player_id
INNER JOIN playerGameStatistics
    ON playerGameStatistics.id = leagueGames.playerGameStatistic_id
ORDER BY game_instance;

/*
-- Aims to get kills from who performd best, as well as creep_score from who
-- performed best for each game instance group. currently just gets MAX(kills) appropiately and then gets
-- the cs of the person that had the highest cs in the group, not the cs of the
-- person who had the highest kills in that group
-- I want the person with the highest kills and then their corresponding statistics
SELECT 
    ingame_name AS "MVP",
    game_instance,
    game_date,
    game_mode,
    game_length,
    MAX(kills) AS "Kills",
    deaths,
    MAX(creep_score) AS "CS"
FROM players
INNER JOIN leagueGames
    ON players.id = leagueGames.player_id
INNER JOIN playerGameStatistics
    ON playerGameStatistics.id = leagueGames.playerGameStatistic_id
GROUP BY game_instance;

*/

/*


WHERE kills = (
    SELECT max(kills) 
    FROM players
    INNER JOIN leagueGames
        ON players.id = leagueGames.player_id
    INNER JOIN playerGameStatistics
        ON playerGameStatistics.id = leagueGames.playerGameStatistic_id
   )

*/


/*
-- DROP TABLE leagueGames, playerGameStatistics, players;

-- The following creates the table and values of what I WANT to see from a query in this database, but unsure how to go about making this query

CREATE TABLE wantedResults(
    name varChar(50),
    game_instance INT,
    game_date DATE,
    game_mode varChar(50),
    game_length TIME,
    kills INT,
    deaths INT,
    CS INT
);

INSERT INTO wantedResults(name,game_instance,game_date,game_mode,game_length,kills,deaths,CS) VALUES
("penpa96",1,"2018-10-27","Ranked Solo","25:11:03",10,2,200),
("penpa96",2,"2018-10-25","ARAM","18:52:25",3,5,30),
("Clout",3,"2018-10-11","Ranked Solo","32:42:52",7,4,256),
("Farlaun",4,"2018-09-30","Ranked Flex","29:21:33",7,7,128),
("Full Aggresive",5,"2018-09-30","Normal","52:39:26",13,6,223);

SELECT * FROM wantedResults;

*/