var express = require("express");
var mysql = require('mysql');
var bodyParser = require("body-parser");
var moment = require('moment');

var app = express();

app.set("view engine", "ejs");
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static(__dirname + "/public"));

var connection = mysql.createConnection({
    host                : 'localhost',
    user                : 'penpa',
    database            : '305_project',
    timezone            : '-0400',
    multipleStatements  : true
    
});

process.on('uncaughtException', function (err) {
  console.error(err);
  console.log("Node NOT Exiting...");
});

app.get("/", function(req, res){
    var q1 = "SELECT * FROM players";
    var q2 = "SELECT * FROM playerGameStatistics";
    var q3 = "SELECT * FROM leagueGames";
    var q4 = "SELECT * FROM playerChampion";
    var q5 = "SELECT * FROM leagueChampion";
    var q6 = "SELECT * FROM playerRank";
    var q7 = "SELECT * FROM leagueRank";
    
    var query = q1+";"+q2+";"+q3+";"+q4+";"+q5+";"+q6+";"+q7;
    connection.query(query, function(err, results){
        if (err) throw err;
        
        
        res.render("home",{moment: moment, players: results[0], statistics: results[1], leagueGames: results[2],
            playerChampion: results[3], leagueChampion: results[4], playerRank: results[5], 
            leagueRank: results[6]
        });
        
    });
    console.log("Hi");
    //console.log("SOMEONE REQUESTED US!");
});
app.get("/players", function(req, res) {
    var q = "SELECT * FROM players";
    connection.query(q, function(err, results){
        if (err) throw err;
        res.render("players",{players: results});
        });
});
app.get("/playergame", function(req, res) {
    var q = "SELECT * FROM playerGameStatistics";
    connection.query(q, function(err, results){
        if (err) throw err;
        res.render("playergame",{statistics: results});
        });
});
app.get("/leaguegame", function(req, res) {
    var q = "SELECT * FROM leagueGames";
    connection.query(q, function(err, results){
        if (err) throw err;
        res.render("leaguegame",{leagueGames: results, moment: moment});
        });
});
app.get("/playerchampion", function(req, res) {
    var q = "SELECT * FROM playerChampion";
    connection.query(q, function(err, results){
        if (err) throw err;
        res.render("playerchampion",{playerChampion: results});
        });
});
app.get("/leaguechampion", function(req, res) {
    var q = "SELECT * FROM leagueChampion";
    connection.query(q, function(err, results){
        if (err) throw err;
        res.render("leaguechampion",{leagueChampion: results});
        });
});
app.get("/playerrank", function(req, res) {
    var q = "SELECT * FROM playerRank";
    connection.query(q, function(err, results){
        if (err) throw err;
        res.render("playerrank",{playerRank: results});
        });
});
app.get("/leaguerank", function(req, res) {
    var q = "SELECT * FROM leagueRank";
    connection.query(q, function(err, results){
        if (err) throw err;
        res.render("leaguerank",{leagueRank: results});
        });
});

app.post("/playerInsert", function(req, res) {
    console.log('post received')
    var player = {
        id: req.body.id,
        ingame_name:req.body.ign,
        level:req.body.level,
        soloMMR:req.body.mmr,
        ladderRank:req.body.ladderRank
    };
    
    console.log(req.body.mrr);
    
    var q = "INSERT INTO players SET ?";
    
    connection.query(q, player, function(error, result) {
        if (error) throw error;
        res.redirect("/players");
    });
})
app.post("/statisticsInsert", function(req, res) {
    console.log('post received')
    var statistic = {
        id: req.body.id,
        kills:req.body.kills,
        deaths:req.body.deaths,
        assists:req.body.assists,
        gold:req.body.gold,
        creep_score:req.body.creep_score,
        kill_participation:req.body.kill_participation
    };
    
    var q = "INSERT INTO playerGameStatistics SET ?";
    
    connection.query(q, statistic, function(error, result) {
        if (error) throw error;
        res.redirect("/playergame");
    });
})
app.post("/leagueGameInsert", function(req, res) {
    console.log('post received')
    var game = {
        id: req.body.id,
        game_instance:req.body.game_instance,
        game_mode:req.body.game_mode,
        game_date:req.body.game_date,
        game_length:req.body.game_length,
        playerGameStatistic_id:req.body.playerGameStatistic_id,
        player_id:req.body.player_id
    };
    
    
    var q = "INSERT INTO leagueGames SET ?";
    
    connection.query(q, game, function(error, result) {
        if (error) throw error;
        res.redirect("/leaguegame");
    });
})
app.post("/playerChampionInsert", function(req, res) {
    console.log('post received')
    var playerChampion = {
        id: req.body.id,
        championName:req.body.championName,
        gamesWon:req.body.gamesWon,
        gamesLOST:req.body.gamesLOST,
        KDA:req.body.KDA,
        creepScore:req.body.creepScore,
        averageDamageTaken:req.body.averageDamageTaken,
        averageDamageDealt:req.body.averageDamageDealt
    };
    
    var q = "INSERT INTO playerChampion SET ?";
    
    connection.query(q, playerChampion, function(error, result) {
        if (error) throw error;
        res.redirect("/playerChampion");
    });
})
app.post("/leagueChampionInsert", function(req, res) {
    console.log('post received')
    var leagueChampion = {
        id: req.body.id,
        championRole: req.body.championRole,
        pickRate: req.body.pickRate,
        winRate: req.body.winRate,
        banRate: req.body.banRate,
        championTier: req.body.championTier,
        counteredBy: req.body.counteredBy,
        counters: req.body.counters,
        playerChampion_id: req.body.playerChampion_id,
        player_id: req.body.player_id,
    };
    
    var q = "INSERT INTO leagueChampion SET ?";
    
    connection.query(q, leagueChampion, function(error, result) {
        if (error) throw error;
        res.redirect("/leagueChampion");
    });
})
app.post("/playerRankInsert", function(req, res) {
    console.log('post received')
    if(req.body.lastSeasonRank_id === "") {
        var playerRank = {
        id: req.body.id,
        rankType: req.body.rankType,
        rankTier: req.body.rankTier,
        rankDivision: req.body.Divsion,
        gamesWon: req.body.gamesWon,
        LP: req.body.LP
    };
    }
    else {
        var playerRank = {
        id: req.body.id,
        rankType: req.body.rankType,
        rankTier: req.body.rankTier,
        rankDivision: req.body.Divsion,
        gamesWon: req.body.gamesWon,
        LP: req.body.LP,
        lastSeasonRank_id: req.body.lastSeasonRank_id,
    };
    }
    
    var q = "INSERT INTO playerRank SET ?";
    
    connection.query(q, playerRank, function(error, result) {
        if (error) throw error;
        res.redirect("/playerrank");
    });
})
app.post("/LeagueRankInsert", function(req, res) {
    console.log('post received')
    var leagueRank = {
        id: req.body.id,
        rankDistribution: req.body.rankDistribution,
        tierDistribution: req.body.tierDistribution,
        tierSurrenderRate: req.body.tierSurrenderRate,
        tierAFKRate: req.body.tierAFKRate,
        playerRank_id: req.body.playerRank_id,
        player_id: req.body.player_id,
    };
    
    var q = "INSERT INTO leagueRank SET ?";
    
    connection.query(q, leagueRank, function(error, result) {
        if (error) throw error;
        res.redirect("/leaguerank");
    });
})

app.listen(8080, function(){
    console.log("Server running on 8080!");
});