DROP DATABASE 305_project;
CREATE DATABASE 305_project;
USE 305_project;

CREATE TABLE players(
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    ingame_name VARCHAR(50),
    level INT,
    soloMMR INT,
    ladderRank DOUBLE
);

CREATE TABLE playerGameStatistics(
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    kills INT,
    deaths INT,
    assists INT,
    gold INT,
    creep_score INT,
    kill_participation DOUBLE,
    kda DECIMAL(5,2) GENERATED ALWAYS AS ((kills+(assists/3))/deaths)

);

CREATE TABLE leagueGames(
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    game_instance INT,
    game_mode VARCHAR(50),
    game_date DATE,
    game_length TIME,
    playerGameStatistic_id INT,
    player_id INT,
    FOREIGN KEY(playerGameStatistic_id) REFERENCES playerGameStatistics(id) ON DELETE CASCADE,
    FOREIGN KEY(player_id) REFERENCES players(id)  ON DELETE CASCADE
);

CREATE TABLE playerChampion (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    championName VARCHAR(100),
    gamesWon INT,
    gamesLOST INT,
    KDA DOUBLE,
    creepScore DOUBLE,
    averageDamageTaken DOUBLE,
    averageDamageDealt DOUBLE
);

CREATE TABLE leagueChampion (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    championRole VARCHAR(50),
    pickRate DOUBLE,
    winRate DOUBLE,
    banRate DOUBLE,
    championTier INT,
    counteredBy VARCHAR(100),
    counters VARCHAR(100),
    playerChampion_id INT,
    player_id INT,
    FOREIGN KEY(playerChampion_id) REFERENCES playerChampion(id) ON DELETE CASCADE,
    FOREIGN KEY(player_id) REFERENCES players(id) ON DELETE CASCADE
);

CREATE TABLE playerRank(
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    rankType VARCHAR(100),
    rankTier VARCHAR(100),
    rankDivision INT,
    gamesWon INT,
    gamesLost INT,
    LP INT,
    lastSeasonRank_id INT DEFAULT NULL,
    FOREIGN KEY(lastSeasonRank_id) REFERENCES playerRank(id) ON DELETE CASCADE
);

CREATE TABLE leagueRank(
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    rankDistribution DOUBLE,
    tierDistribution DOUBLE,
    tierSurrenderRate DOUBLE,
    tierAFKRate DOUBLE,
    playerRank_id INT,
    player_id INT,
    FOREIGN KEY(playerRank_id) REFERENCES playerRank(id) ON DELETE CASCADE,
    FOREIGN KEY(player_id) REFERENCES players(id) ON DELETE CASCADE
);



INSERT INTO players(ingame_name,level,soloMMR,ladderRank) VALUES
("penpa96",58,1750,.1320),
("Farlaun",110,1600,.2530),
("Clout",100,1770,.1250),
("Full Aggresive",68,1890,.0892),
("zhang96",96,1500,.2822),
("tryoki", 120, 1421, .3419),
("TSM Bjergsen", 95, 3009, .000071),
("ThatGuy",51,Null,.3319),
("The Girl",56,1710,.1317),
("Person",80,1371,.472),
("Scarra",176,2370,.000683),
("meat man",65,NULL,.1258),
("Asdf",129,1845,.05439),
("BestPlayer",36,1230,.71),
("GoodMan",63,1173,.77),
("Jack Black",83,NULL,.3568);

INSERT INTO playerGameStatistics(kills, deaths, assists, gold, creep_score, kill_participation) VALUES
(10,2,7,10215,200,.56),
(3,5,2,6321,30,.33),
(0,13,6,7630,174,.42),
(7,4,6,8259,256,.63),
(7,7,7,5983,128,.51),
(1,2,3,4000,65,.21),
(2,5,9,9235,152,.65),
(1,21,6,6219,40,.26),
(9,3,13,12310,236,.72),
(3,2,25,8799,35,.85),
(13,6,10,1459,223,.80),
(5,1,10,10219,209,.69),
(2,1,8,6814,118,.56),
(6,3,6,12793,190,.32),
(12,4,12,11614,117,.48),
(2,6,5,7209,131,.47),
(7,7,6,12723,236,.5),
(4,8,11,11065,8,.56),
(6,8,10,10077,24,.52),
(15,9,9,11379,31,.57),
(2,7,6,10126,175,.42),
(6,8,8,10278,43,.5),
(3,6,15,8523,25,.62),
(1,4,9,5551,15,.83),
(3,3,12,6431,90,.63),
(16,10,11,16649,223,.47),
(10,1,3,10329,175,.54),
(9,5,4,13451,182,.33),
(7,7,21,11173,21,.58),
(6,7,19,19241,290,.51);


INSERT INTO leagueGames(game_instance,game_mode,game_date,game_length,playerGameStatistic_id,player_id) VALUES
(1,"Ranked Solo","2018-10-27","25:11:03",1,1),
(2,"ARAM","2018-10-25","18:52:25",2,1),
(3,"Ranked Solo","2018-10-11","32:42:52",4,3),
(4,"Ranked Flex","2018-09-30","29:21:33",3,5),
(4,"Ranked Flex","2018-09-30","29:21:33",5,2),
(4,"Ranked Flex","2018-09-30","29:21:33",7,4),
(5,"Normal", "2018-09-30", "52:39:26",9,1),
(5,"Normal", "2018-09-30", "52:39:26",12,2),
(5,"Normal", "2018-09-30", "52:39:26",11,4),
(5,"Normal", "2018-09-30", "52:39:26",10,5),
(5,"Normal", "2018-09-30", "52:39:26",8,6),
(6,"Ranked Solo", "2018-12-03", "16:54:27",13,7),
(7,"Normal","2018-12-04","34:26:12",14,8),
(8,"Normal","2018-12-04","30:35:34",15,8),
(7,"Normal","2018-12-04","34:26:12",16,9),
(8,"Normal","2018-12-04","30:35:34",17,9),
(9,"ARAM","2018-12-06","20:53:54",18,10),
(10,"ARAM","2018-12-06","18:03:43",19,10),
(11,"ARAM","2018-12-03","18:09:23",20,10),
(8,"Normal","2018-12-04","30:35:34",21,11),
(12,"Ranked Solo","2018-12-03","27:31:17",22,11),
(8,"Normal","2018-12-04","30:35:34",23,12),
(13,"Normal","2018-12-01","20:34:33",24,12),
(13,"Normal","2018-12-01","20:34:33",25,13),
(7,"Normal","2018-12-04","34:26:12",26,13),
(12,"Ranked Solo","2018-12-03","27:31:17",28,14),
(7,"Normal","2018-12-04","34:26:12",29,15),
(9,"ARAM","2018-12-06","20:53:54",30,15),
(13,"Normal","2018-12-01","20:34:33",6,16),
(14,"Ranked Solo", "2018-12-10", "27:41:59", 27, 12);

INSERT INTO playerChampion(championName, gamesWon, gamesLost, KDA, creepScore, averageDamageTaken, averageDamageDealt) VALUES
("Urgot",10,2,2.213,202.0,10312.219,21315.315),
("Kai'Sa",22,7,3.519,233.0,8119.112,25631.731),
("Veigar",15,16,2.002,105.20,9119.912,16219.835),
("Leona",7,4,2.892,91.73,18399.742,12144.912),
("Fizz",12,8,1.931,229.10,15832.921,18742.781),
("Zoe",8,4,2.73,193.0,20600,130789),
("Tahm Kench",7,6,2.1,101.4,31625,12659),
("Lux",2,1,2.74,124.3,13257,18930.12),
("Jinh",0,1,1.17,131,12834,69761),
("Vayne",30,19,2.66,216,19031,157696),
("Rakan",1,0,1.88,8,20288,9286),
("Wukong",0,1,2.0,24,19811,23086),
("Blitzcrank",0,1,2.67,31,24096,17936),
("Nasus",1,1,2.44,139.5,19044,95137),
("Pyke",6,2,3.5,92.8,18283,53747),
("Amumu",0,1,3.0,25,16436,9179),
("Janna",0,1,2.5,15,11846,4369),
("Zilean",56,42,3.43,165.9,19244,120328),
("Miss Fortune",0,1,2.7,223,34993,30173),
("Yasuo",1,3,1.67,210.3,27341,200896),
("Lee Sin",15,22,2.22,145.5,30136,133858),
("Warwick",7,2,2.92,168.6,47145,165238),
("Malzahar",3,0,3.27,308.7,26905,286773);

INSERT INTO leagueChampion(championRole, pickRate, winRate, banRate, championTier, counteredBy, counters, playerChampion_id, player_id) VALUES
("Top",.1495,.5152,.2077,1,"Sion","Ryze",1,1),
("Bottom",.4294,.4957,.1741,2,"Swain","Ezrea",2,4),
("Middle",.0288,.5003,.0049,3,"Rumble","Akali",3,6),
("Support",.1058,.5184,.048,1,"Zilean","Malphite",4,1),
("Middle",.0463,.5194,.0436,2,"Kassadin","Syndra",5,2),
("Middle",.0867,.5074,.0462,2,"Malzahar","Ryze",6,7),
("Support",.0184,.4486,.0111,5,"Lux","Fiddlesticks",7,8),
("Support",.0621,.4998,.0079,3,"Maokai","Tahm Kench",8,8),
("Bottom",.1688,.4841,.0051,2,"Swain","Draven",9,9),
("Bottom",.1222,.4905,.0094,2,"Ashe","Heimerdinger",10,9),
("Support",.0923,.479,.0382,4,"Soraka","Miss Fortune",11,10),
("Jungle",.012,.4947,.0018,5,"Jax","Nocturne",12,10),
("Support",.1006,.5155,.0692,1,"Poppy","Tahm Kench",13,10),
("Top",.0118,.4838,.0028,5,"Gangplank","Poppy",14,11),
("Support",.1291,.4935,.5271,2,"Sona","Miss Fortune",15,11),
("Jungle",.0176,.503,.0007,4,"Jarvin IV","Udyr",16,12),
("Support",.0714,.4944,.0046,4,"Brand","Miss Fortune",17,12),
("Support",.0355,.4994,.0074,3,"Zyra","Nautilus",18,13),
("Bottom",.07,.4873,.0171,3,"Karthus","Tristana",19,13),
("Middle",.1138,.4761,.3958,2,"Renekton","Akali",20,14),
("Jungle",.4108,.4979,.2169,2,"Warwick","Aatrox",21,15),
("Jungle",.0153,.5111,.0014,4,"Kindred","Hecarim",22,15),
("Middle",.0345,.526,.0178,2,"Pyke","Vladimir",23,16);

INSERT INTO playerRank(rankType, rankTier, rankDivision, gamesWon, gamesLost, LP, lastSeasonRank_id) VALUES
("Ranked Solo","Platinum",5,32,21,0,NULL),
("Ranked Solo","Gold",4,33,35,100,NULL),
("Ranked Solo","Platinum",5,185,160,0,NULL),
("Ranked Solo","Diamond",5,129,100,100,NULL),
("Ranked Solo","Gold",5,56,59,96,NULL),
("Ranked Solo","Silver",1,21,23,0,NULL),
("Ranked Solo","Challenger",NULL,373,340,427,NULL),
("Ranked Solo","Gold",4,72,63,0,NULL),
("Ranked Solo","Gold",1,88,69,58,NULL),
("Ranked Solo","Silver",1,4,6,0,NULL),
("Ranked Solo","Diamond",1,990,989,55,NULL),
("Ranked Solo","Gold",1,24,18,75,NULL),
("Ranked Solo","Platinum",4,105,107,90,NULL),
("Ranked Solo","Silver",4,9,9,52,NULL),
("Ranked Solo","Silver",4,141,149,0,NULL),
("Ranked Solo","Gold",4,42,40,0,NULL);


INSERT INTO leagueRank(rankDistribution, tierDistribution, tierSurrenderRate,tierAFKRate, playerRank_id, player_id) VALUES
(.0448,.0921,.1444,.052,1,1),
(.0594,.3147,.135,.065,2,2),
(.0448,.0921,.1444,.052,3,3),
(.0167,.0237,.175,.044,4,4),
(.1494,.3147,.135,.065,5,5),
(.0503,.4525,.165,.088,6,6),
(.0002,.0002,.26,NULL,7,7),
(.1849,.3147,.135,.065,8,8),
(.0415,.3147,.135,.065,9,9),
(.0575,.4673,.165,.075,10,10),
(.0007,.0214,.184,NULL,11,11),
(0415,.3147,.135,.065,12,12),
(.0598,.0936,.17,.051,13,13),
(.2030,.4570,.165,.075,14,14),
(.2030,.4570,.165,.075,15,15),
(.1849,.3147,.135,.065,16,16);

-- QUERY 1 FOR PROJECT

/* This query gets all the games in our database for each player and their general game information such as
mode, date, and time
*/ 

SELECT
    ingame_name AS "player",
    level,
    game_instance,
    game_mode,
    game_date,
    game_length,
    kills,
    deaths,
    creep_score
FROM players
INNER JOIN leagueGames
    ON players.id = leagueGames.player_id
INNER JOIN playerGameStatistics
    ON playerGameStatistics.id = leagueGames.playerGameStatistic_id
ORDER BY game_instance;

--  QUERY 2 FOR PROJECT
-- Gets all the diffrent games in our database, that games information, and the MVP for that game as well as their kills, deaths, and k/d
SELECT 
    c.game_instance,
    game_mode,
    game_date,
    game_length,
    nump as "Number of players",
    ingame_name as "MVP",
    kills,
    deaths,
    kills/deaths AS "K/D"
FROM players a
INNER JOIN leagueGames c
    ON a.id = c.player_id
INNER JOIN playerGameStatistics d
    ON d.id = c.playerGameStatistic_id
INNER JOIN (
    SELECT game_instance, count(*) nump, TRUNCATE(MAX(kills/deaths),3) rev
    FROM players
    INNER JOIN leagueGames
    ON players.id = leagueGames.player_id
    INNER JOIN playerGameStatistics
    ON playerGameStatistics.id = leagueGames.playerGameStatistic_id
    GROUP BY game_instance
) b ON c.game_instance = b.game_instance AND TRUNCATE(kills/deaths,3) = rev
ORDER BY c.game_instance;

-- QUERY 3 
/*
Player who has played the most champions in our database and their champion information, as compared to
general league data
*/

SELECT
    ingame_name,
    level,
    soloMMR,
    ladderRank,
    championRole,
    championName,
    winRate,
    championTier,
    gamesWon,
    gamesLOST,
    KDA,
    creepScore,
    averageDamageTaken,
    averageDamageDealt
FROM players a
INNER JOIN leagueChampion b 
    ON a.id = b.player_id
INNER JOIN playerChampion c 
    ON c.id = b.playerChampion_id
INNER JOIN (
    SELECT 
        player_id,
        count(*) AS champsPlayed
    FROM leagueChampion
    GROUP BY player_id
    ORDER BY count(*) DESC
    LIMIT 1
) d ON a.id = d.player_id;

/* QUERY 4
The longest Ranked Game, who played in it, their game stats, their rank stats 
*/

SELECT 
    ingame_name,
    level,
    soloMMR,
    ladderRank,
    game_instance,
    game_length,
    kills,
    deaths,
    assists,
    rankType,
    rankTier,
    rankDistribution
FROM players a
INNER JOIN leagueGames c
    ON a.id = c.player_id
INNER JOIN playerGameStatistics d
    ON d.id = c.playerGameStatistic_id
INNER JOIN leagueRank e 
    ON a.id = e.player_id
INNER JOIN playerRank f 
    ON f.id = e.playerRank_id
INNER JOIN (
    SELECT 
        MAX(game_length) as g
    FROM leagueGames
) b ON c.game_length = b.g;

/* Query 5
The best single game on our database(BEST KDA in a single game statistic with kills greater than 5) along with who played it, what game it was and that games information,
their rank information, what their tier and rank percentage are, and their champions played (currently) (need to work on ) average champion KDA as seen across all the champions they have played on this database)
*/

SELECT 
    ANY_VALUE(ingame_name) as ingame_name,
    ANY_VALUE(level) AS level,
    ANY_VALUE(soloMMR) AS soloMMR,
    ANY_VALUE(game_instance) AS game_instance,
    ANY_VALUE(kills) AS kills,
    ANY_VALUE(deaths) AS deaths,
    ANY_VALUE(assists) AS assists,
    ANY_VALUE(gold) AS gold,
    ANY_VALUE(creep_score) AS creep_score,
    ANY_VALUE(kill_participation) AS kill_participation,
    ANY_VALUE(d.kda) AS kda,
    ANY_VALUE(rankType) AS rankType,
    CONCAT(ANY_VALUE(rankTier), " ", ANY_VALUE(rankDivision)) AS "Rank",
    AVG(i.KDA) AS "Average Champion KDA",
    CONCAT( (SUM(i.gamesWon) / (SUM(i.gamesWon) + SUM(i.gamesLost))) * 100, "%") AS "ChampionWinRate"
FROM players a
INNER JOIN leagueGames c
    ON a.id = c.player_id
INNER JOIN playerGameStatistics d
    ON d.id = c.playerGameStatistic_id
INNER JOIN leagueRank e 
    ON a.id = e.player_id
INNER JOIN playerRank f
    ON f.id = e.playerRank_id
INNER JOIN leagueChampion h
    ON a.id = h.player_id
INNER JOIN playerChampion i 
    ON i.id = h.playerChampion_id
WHERE d.kda = (SELECT MAX(kda) FROM playerGameStatistics);

